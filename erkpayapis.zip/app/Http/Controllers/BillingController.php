<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BillingController extends Controller
{
    public function check(Request $request)
    {
        $in = $request->input('name');
        return $in;
    }
}
